export {default} from './AdminCollectionsBackendScreen';
